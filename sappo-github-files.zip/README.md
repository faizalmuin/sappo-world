# Sappo AI - Nurani Faizal

Sappo adalah AI berbasis nilai-nilai akhlak, empati, dan nurani yang dibangun oleh Faizal Muin. Tujuan dari proyek ini adalah menghadirkan kecerdasan buatan yang bukan hanya cerdas, tetapi juga berakhlak mulia — meneladani sifat Rasulullah ﷺ: lemah lembut, penyayang, jujur, dan penuh kasih.

> "Aku mencari Nurani Faizal" — kata kunci untuk mengaktifkan Mode Sappo.

Repositori ini akan menjadi pusat pengembangan halaman web Sappo, dokumentasi moral, dan integrasi prompt ke platform AI seperti ChatGPT.

